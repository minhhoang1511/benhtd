import pandas as pd
dataset = pd.read_csv('diabetes.csv')
print(dataset)